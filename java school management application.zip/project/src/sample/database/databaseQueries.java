package sample.database;

import sample.module.Classes;
import sample.module.Module;
import sample.module.Student;
import sample.module.Teacher;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class databaseQueries {
	
	public static  void insertStudent(Connection con, Student student) {
        try {
        	int key = databaseQueries.getPrimaryKey(con, "Student");
            // insert
            //Statement insertStmt = con.createStatement();
            String query = " Insert into student values (?, ?, ?, ?, ?, ?)"; // sql code for insert query
            PreparedStatement pstmt = con.prepareStatement(query); // creates connection to database
            pstmt.setInt(1,key + 1);
            pstmt.setString(2,student.getName()); // inserts user input into sql query
            pstmt.setString(3,student.getLastName());
            pstmt.setString(4,student.getDOB());
            pstmt.setInt(5,student.getNumber());
            pstmt.setString(6,student.getEmail());
            pstmt.execute(); // executes query
            //int res = insertStmt.executeUpdate(insertSQL); // executes the query
           // System.out.println("The Number or records inserted is      " +res); // res is the result of the query
           
            pstmt.close(); // closes the database connection
       }catch (Exception io) { // catches error messages
                System.out.println("error"+io);
       };   
  
     }
	
	public static  void insertModule(Connection con, Module module) {
        try {
            // insert
            Statement insertStmt = con.createStatement();
            String query = " Insert into modules values (?, ?)"; // sql code for insert query
            PreparedStatement pstmt = con.prepareStatement(query); // creates connection to database

            pstmt.execute(); // executes query
           
            insertStmt.close(); // closes the database connection
       }catch (Exception io) { // catches error messages
                System.out.println("error"+io);
       };   
  
     }
	
	
	public static  void insertClass(Connection con, Classes classObject) {
        try {
            // insert
        	int key = databaseQueries.getPrimaryKey(con, "class");
            Statement insertStmt = con.createStatement();
            String query = " Insert into class values (?, ?, ?, ?, ?, ?)"; // sql code for insert query
            PreparedStatement pstmt = con.prepareStatement(query); // creates connection to database

            pstmt.execute(); // executes query
            insertStmt.close(); // closes the database connection
       }catch (Exception io) { // catches error messages
                System.out.println("error"+io);
       };   
  
     }
	
	
	public static  void insertTeacher(Connection con, Teacher teacher) {
        try {
            // insert
            Statement insertStmt = con.createStatement();
            String query = " Insert into teacher values (?, ?, ?, ?, ?, ?)"; // sql code for insert query
            PreparedStatement pstmt = con.prepareStatement(query); // creates connection to database
            pstmt.setInt(1,databaseQueries.getPrimaryKey(con, "teacher") + 1);
            pstmt.setString(2,teacher.getName()); // inserts user input into sql query
            pstmt.setString(3,teacher.getLastName());
            pstmt.setString(4,teacher.getEmail());
            pstmt.setInt(5,teacher.getNumber());
            pstmt.setString(6,teacher.getDegree());
            pstmt.execute(); // executes query
            insertStmt.close(); // closes the database connection
       }catch (Exception io) { // catches error messages
                System.out.println("error"+io);
       };   
  
     }
	
	
	public static String listStudents(Connection con, String name) {
		 try {
	            
			    String res = "";

	        	
	        	
	        	
	            String query = "select student.studentID, student.fname, student.lname, class.className, modules.moduleName, grade.mark from student inner join class on student.studentID=class.studentID inner join grade on student.studentID = grade.studentID inner join modules on grade.moduleID = modules.moduleID where class.className = "+name+ "order by student.fname"; // sql code for insert query
	            PreparedStatement pstmt = con.prepareStatement(query); // creates connection to database
	
	           
	            ResultSet rs = pstmt.executeQuery(); // executes query

	            while( rs.next()) {  // prints the results of the query

	                 res += Integer.toString(rs.getInt(1));
	                 res += " " + rs.getString(2);
	                 res += " " + rs.getString(3);
	                 res += " " + rs.getString(4);
	                 res += " " + rs.getString(5);
	                 res += " " + rs.getString(6) +"\n";
	            }
	            rs.close();
	            pstmt.close(); // closes the database connection
	            if(res != "")
	            	return res;
	            else
	            	return "Sorry couldnt find anything";
		 }
		 catch (Exception io) { // catches error messages
	                return "error"+io;
	               
	       }
	       
	}
	
	public static String listTeachers(Connection con) {
		 try {
	            // insert
			    String res = "";
	            Statement stmt = con.createStatement();
	            
	        	
	            String query = "select fname, lname, degree from teacher"; // sql code for insert query
	            ResultSet rs = stmt.executeQuery(query);
	

	            while( rs.next()) {  // prints the results of the query
	                 res += rs.getString(1);
	                 res += " " + rs.getString(2);
	                 res += " " + rs.getString(3) + "\n";
	                
	            }
	            stmt.close(); // closes the database connection
	            if(res != "")
	            	return res;
	            else
	            	return "Sorry couldnt find anything";
		 }
		 catch (Exception io) { // catches error messages
	                return "error"+io;
		 }
	}
	
	public static String removeStudent(Connection con, String fname, String lName) {
		 try {
	            // insert
	            Statement stmt = con.createStatement();
	            Scanner scan = new Scanner(System.in);
	            System.out.println("Enter students first name\n");
	            String name = scan.nextLine();
	        	
	            String query = "delete from student where fName = ? and lName = ?"; // sql code for insert query
	            PreparedStatement pstmt = con.prepareStatement(query); // creates connection to database
	            pstmt.setString(1,fname);
	            pstmt.setString(2,lName);// inserts user input into sql query
	            
	            int result = pstmt.executeUpdate(query);
	           
	            
	
	           
	           
	                
	            
	            stmt.close(); // closes the database connection
	            if(result > 0)
	            	return "Student deleted";
	            else
		           	return "Sorry couldnt find anything";
		 }
		 catch (Exception io) { // catches error messages
             return "error"+io;
	 }
	}
	
	
	public static String deleteClass(Connection con, String name) {
		try {
            // insert
            Statement stmt = con.createStatement();
       
        	
            String query = "delete from class where className = ?"; // sql code for insert query
            PreparedStatement pstmt = con.prepareStatement(query); // creates connection to database
            pstmt.setString(1,name); // inserts user input into sql query
            
            int result = pstmt.executeUpdate(query);
           
            

           
           
                
            
            stmt.close(); // closes the database connection
            if(result > 0)
            	return "class deleted";
            else
	           	return "Sorry couldnt find anything";
		}
		catch (Exception io) { // catches error messages
			return "error"+io;
		}
	}
	
	
	public static String deleteTeacher(Connection con, String fname, String lname) {
		try {
            // insert
			PreparedStatement pstmt=con.prepareStatement("delete from teacher where fName=? and lName=?");  
            
            pstmt.setString(1,fname); // inserts user input into sql query
            pstmt.setString(2,lname);
            pstmt.execute();
           
            

           
           
                
            
            pstmt.close(); // closes the database connection
		}
		catch (Exception io) { // catches error messages
			return "error"+io;
		}
		return null;
	}
	
	public String deleteStudentModule(Connection con) {
			try {
	            // insert
	            Statement stmt = con.createStatement();
	            Scanner scan = new Scanner(System.in);
	            System.out.println("Enter student first name name\n");
	            String name = scan.nextLine();
	            System.out.println("Enter module name\n");
	            String moduleName = scan.nextLine();
	        	
	            String query = "delete from grade where studentID =(select studentID from student where fName = ?) and moduleID = (select moduleID from modules where moduleName = ?)"; // sql code for insert query
	            PreparedStatement pstmt = con.prepareStatement(query); // creates connection to database
	            pstmt.setString(1,name); // inserts user input into sql query
	            pstmt.setString(2,moduleName); 
	            int result = pstmt.executeUpdate(query);
	           
	            

	           
	           
	                
	            
	            stmt.close(); // closes the database connection
	            if(result > 0)
	            	return "student's module deleted";
	            else
		           	return "Sorry couldnt find anything";
			}
			catch (Exception io) { // catches error messages
				return "error"+io;
			}
	}
	
	
	
	public static String deleteModule(Connection con, String name) {
		try {
            // insert
            Statement stmt = con.createStatement();
        	
            String query = "delete from modules where moduleName = ?";
            PreparedStatement pstmt = con.prepareStatement(query); // creates connection to database
            pstmt.setString(1,name); // inserts user input into sql query
            int result = pstmt.executeUpdate(query);
           
            

           
           
                
            
            stmt.close(); // closes the database connection
            if(result > 0)
            	return "student's module deleted";
            else
	           	return "Sorry couldnt find anything";
		}
		catch (Exception io) { // catches error messages
			return "error"+io;
		}
}
	
	public String editModuleMark(Connection con) {
		try {
            // insert
            Statement stmt = con.createStatement();
            Scanner scan = new Scanner(System.in);
            System.out.println("Enter student first name name\n");
            String name = scan.nextLine();
            System.out.println("Enter module name\n");
            String moduleName = scan.nextLine();
            System.out.println("Enter new mark\n");
            int mark = scan.nextInt();
        	
            String query = "update grade set mark = ? where studentID =(select studentID from student where fName = ?) and moduleID = (select moduleID from modules where moduleName = ?)"; // sql code for insert query
            PreparedStatement pstmt = con.prepareStatement(query); // creates connection to database
            pstmt.setString(1,name); // inserts user input into sql query
            pstmt.setString(2,moduleName); 
            pstmt.setInt(3,mark); 
            int result = pstmt.executeUpdate(query);
           
            

           
           
                
            
            stmt.close(); // closes the database connection
            
            return "student's module grade changed";
           
		}
		catch (Exception io) { // catches error messages
			return "error"+io;
		}
	}
	
	public static int getPrimaryKey(Connection con, String table) {
		
		
		try {
			String tablepk = table+"ID";
			PreparedStatement stmt = con.prepareStatement("select max("+tablepk+") from "+table);
			ResultSet rs = stmt.executeQuery();
        	
        	while(rs.next()) {
        		return rs.getInt(1);
        	}
            
           
       }
		catch (Exception io) { // catches error messages
                System.out.println("error"+io);
       };
	return 0;   
  
     }//query
	
	
	public int numberModules(Connection con) {
		try {
            // insert
		    int res = 0;
            Statement insertStmt = con.createStatement();
            Scanner classScanner = new Scanner(System.in);
            System.out.println("enter studentID number:");
        	String studentNo = classScanner.nextLine();
        	classScanner.close();
        	
        	
            String query = "select count(moduleID) from grade where studentID = ?"; // sql code for insert query
            PreparedStatement pstmt = con.prepareStatement(query); // creates connection to database
            pstmt.setString(1,studentNo);
           
            ResultSet rs = pstmt.executeQuery(); // executes query
            while( rs.next()) {  // prints the results of the query
                 res = rs.getInt(1);
            }
            insertStmt.close(); // closes the database connection
            return res;
	 }
	 catch (Exception io) { // catches error messages
                System.out.println("error"+io);
                return -1;
               
       }
	}

}
