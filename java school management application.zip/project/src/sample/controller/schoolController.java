package sample.controller;

public class schoolController {
	
	
	public static boolean validateStudent(String fname, String lName, String email,String number, String DOB) {
		boolean res = true;
		String [] validate = {fname, lName, email, number, DOB};
		for(int i = 0; i < validate.length; i++) {
			if(i == 3)
				if(Integer.parseInt(validate[i]) < 1) {
					res = false;
				}
			
			else if(validate[i] == null | validate[i] == "")
				res = false;
		}
		
		
		
		return res;
	}
	
	public static boolean validateTeacher(String name, String lName, String email, String number, String degree) {
		boolean res = true;
		String [] validate = { name, lName, email, number, degree};
		for(int i = 0;  i < validate.length; i++) {
			if(i == 3) 
				if(Integer.parseInt(validate[i]) < 1) {
					res = false;
				}
			
			
			
			if(validate[i] == "" | validate[i] == null)
				res = false;
		}
		
		return res;
	}
	
	
	public static boolean validateModuleAndClass(String name) {
		boolean res = true;
		if(name == null | name == "")
			res = false;
		
		return res;
	}
	
	
}
