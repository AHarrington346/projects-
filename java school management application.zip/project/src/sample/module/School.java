package sample.module;

import java.util.ArrayList;

public class School {
	ArrayList<Class> schoolClasses = new ArrayList<Class>();
	
	
	public void removeClass(Class id)
	{
		schoolClasses.remove(id);
	}
	
	public Class getClass(int position) {
		return schoolClasses.get(position);
	}
	
	public void addClass(Class classAdd) {
		schoolClasses.add(classAdd);
	}
	
}
