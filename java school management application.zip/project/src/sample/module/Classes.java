package sample.module;

import java.util.ArrayList;

public class Classes {
	private String name;
	
	public Classes(String name) {
		this.name = name;
	}
	
	public String getClassName() {
		return this.name;
	}
	
	public void setClassName(String name) {
		this.name = name;
	}
	
	
	

}
