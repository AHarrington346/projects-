package sample.module;

import java.util.HashMap;

public class Module {
	private String moduleName;
    private HashMap<String, Integer> grade;
	
	public Module(String name) {
		this.moduleName = name;
		this.grade = new HashMap<String, Integer>();
	}
	
	public void addStudent(String obj, int grade) {
		this.grade.put(obj, grade);
	}
	
	public void removeStudent(String student) {
		this.grade.remove(student);
	}
	
	public String getName() {
		return this.moduleName;
	}
	
	public void setName(String name) {
		this.moduleName = name;
	}
	
	public String printModule() {
		String res = this.moduleName+"\n";
		
		for(String key : this.grade.keySet()) 
			res += key + " - " + this.grade.get(key) + "\n";
		
		return res;
			
	}
	
	

}
