package sample.application;

import java.sql.Connection;


import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import sample.controller.schoolController;
import sample.database.ConnectToMySQL;
import sample.database.databaseQueries;
import sample.module.Module;
import sample.module.Classes;
import sample.module.Student;
import sample.module.Teacher;


public class Main extends Application {

    Scene scene, scene2, scene3;
    Button add, remove, listStudents, listTeachers, addStudent, addTeacher, addClass, addModule, removeStudent, removeTeacher, removeClass, removeModule, changeScene, changeScene2;
    TextField rModule, rClass, rTSName, rTFName, rSSName, rSFName, sFName, sLName, sEmail, sNumber, sDOB, tName, tLName, tEmail, tNumber, tDegree, mName, cName;
    TextArea display, addDisplay, removeDisplay;
    Label student, teacher, groupClass, module;
    @Override

    public void start(Stage primaryStage) {
        Connection con = ConnectToMySQL.createConnection();
        int k = databaseQueries.getPrimaryKey(con, "student");

        Stage window = primaryStage;
        addStudent = new Button("addStudent");
        addTeacher = new Button("addTeacher");
        addClass = new Button("addClass");
        addModule = new Button("addModule");
        changeScene2 = new Button("Home");


        changeScene2.setOnAction(e -> window.setScene(scene3));
        addStudent.setOnAction(e -> {
            if(schoolController.validateStudent(sFName.getText(), sLName.getText(),sEmail.getText(), sNumber.getText(), sDOB.getText()))
                databaseQueries.insertStudent(con, new Student(sFName.getText(), sLName.getText(), sEmail.getText(), Integer.parseInt(sNumber.getText()), sDOB.getText()));
        });

        addTeacher.setOnAction(e -> {
            if(schoolController.validateTeacher(tName.getText(), tLName.getText(),tEmail.getText(), tNumber.getText(), tDegree.getText()))
                databaseQueries.insertTeacher(con, new Teacher(tName.getText(), tLName.getText(),tEmail.getText(), Integer.parseInt(tNumber.getText()), tDegree.getText()));


        });

        addClass.setOnAction(e -> {
            if(schoolController.validateModuleAndClass(cName.getText()))
                databaseQueries.insertClass(con,  new Classes(cName.getText()));

        });


        addModule.setOnAction(e -> {
            if(schoolController.validateModuleAndClass(mName.getText()))
                databaseQueries.insertModule(con, new Module(mName.getText()));
        });


        student = new Label("Student");

        sFName = new TextField();
        sFName.setPromptText("student First name");
        sLName = new TextField();
        sLName.setPromptText("student last name");
        sEmail = new TextField();
        sEmail.setPromptText("student email");
        sNumber = new TextField();
        sNumber.setPromptText("student number");
        sDOB = new TextField();
        sDOB.setPromptText("dd/mm/yyyy");

        teacher = new Label("Teacher");

        tName = new TextField();
        tName.setPromptText("teacher name");
        tLName = new TextField();
        tLName.setPromptText("teacher last name");
        tEmail = new TextField();
        tEmail.setPromptText("teacher email");
        tNumber = new TextField();
        tNumber.setPromptText("teacher number");
        tDegree = new TextField();
        tDegree.setPromptText("teacher degree");

        module = new Label("Module");

        mName = new TextField();
        mName.setPromptText("module name");

        groupClass = new Label("Class");

        cName = new TextField();
        cName.setPromptText("Class Name");

        HBox sLayout = new HBox();
        sLayout.getChildren().addAll(sFName, sLName, sEmail, sNumber, sDOB);

        HBox tLayout = new HBox();
        tLayout.getChildren().addAll(tName,tLName, tEmail, tNumber, tDegree);

        HBox mLayout = new HBox();
        mLayout.getChildren().add(mName);

        HBox cLayout = new HBox();
        cLayout.getChildren().add(cName);

        addDisplay = new TextArea();

        VBox layout = new VBox(5);
        layout.getChildren().addAll(student, sLayout, addStudent, teacher, tLayout, addTeacher, module, mLayout, addModule, groupClass, cLayout, addClass, addDisplay, changeScene2);
        //, addStudent, teacher, tLayout, addTeacher, module, mLayout, addModule, groupClass, cLayout, addClass
        scene = new Scene(layout, 500, 500);






        //remove
        removeStudent = new Button("removeStudent");
        removeTeacher = new Button("removeTeacher");
        removeClass = new Button("removeClass");
        removeModule = new Button("removeModule");
        changeScene = new Button("Home");

        changeScene.setOnAction(e -> window.setScene(scene3));
        removeStudent.setOnAction(e -> {
            if(rSFName.getText() != "" && rSSName.getText() != "")
                databaseQueries.removeStudent(con, rSFName.getText(), rSSName.getText());
        });
        removeTeacher.setOnAction(e -> {
            if(rTFName.getText() != "" && rTSName.getText() != "")
                databaseQueries.deleteTeacher(con, rTFName.getText(), rTSName.getText());
        });
        removeClass.setOnAction(e -> {
            if(rClass.getText() != "")
                databaseQueries.deleteClass(con, rClass.getText());
        });
        removeModule.setOnAction(e -> {
            if(schoolController.validateModuleAndClass(rModule.getText()))
                databaseQueries.deleteModule(con, rModule.getText());
        });

        rSFName = new TextField();
        rSFName.setPromptText("Student First Name");

        rSSName = new TextField();
        rSSName.setPromptText("Student Second Name");
        HBox rSLayout = new HBox();
        rSLayout.getChildren().addAll(rSFName, rSSName);

        rTFName = new TextField();
        rTFName.setPromptText("Teacher First Name");

        rTSName = new TextField();
        rTSName.setPromptText("Teacher Second Name");
        HBox rTLayout = new HBox();
        rTLayout.getChildren().addAll(rTFName, rTSName);

        rClass = new TextField();
        rClass.setPromptText("Class Name");

        rModule = new TextField();
        rModule.setPromptText("Module Name");

        removeDisplay = new TextArea();

        VBox layout2 = new VBox(5);
        layout2.getChildren().addAll(rSLayout, removeStudent, rTLayout, removeTeacher, rModule, removeModule, rClass, removeClass, removeDisplay, changeScene);
        scene2 = new Scene(layout2, 500, 500);






        //home
        add = new Button("Add");
        remove = new Button("Remove");
        listStudents = new Button("List Students");
        listTeachers = new Button("List Teachers");

        add.setOnAction(e -> window.setScene(scene));
        remove.setOnAction(e -> window.setScene(scene2));
        listStudents.setOnAction(e -> display.setText(databaseQueries.listStudents(con, "class")));
        listTeachers.setOnAction(e -> display.setText(databaseQueries.listTeachers(con)));

        display = new TextArea();
        VBox homeDisplay = new VBox(5);
        homeDisplay.getChildren().addAll(add, remove, listStudents, listTeachers, display);
        scene3 = new Scene(homeDisplay, 500, 500);

        window.setScene(scene3);
        window.show();

    }

    public static void main(String[] args) {
        launch(args);
    }
}
