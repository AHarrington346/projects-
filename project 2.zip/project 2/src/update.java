import java.sql.*;

public class update {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			// 1. connection to database 
			Connection myCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Munstermad14");
			// 2. create a statement 
			Statement myStmt=myCon.createStatement();
			//3. execute sql query
			String sql = "update employees"+"set age ='30'"+"set name='john'"+"set position='driver'"+"where eID=9";
			String sql2 = "update packages" +"set type='small'"+"where pID=11";
			String sql3="update distribution"+"set name='jack'"+"where orderNum=5";
			String sql4="update orders"+"set maker='LG'"+"where orderNum=7";
			
			myStmt.executeUpdate(sql);
			myStmt.executeUpdate(sql2);
			myStmt.executeUpdate(sql3);
			myStmt.executeUpdate(sql4);
			
			// 4. process result set 
			System.out.println("update complete");
		}
		catch (Exception exc) {
			exc.printStackTrace();
		}

	}

}
