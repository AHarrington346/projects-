import java.sql.*;
public class delete {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			// 1. connection to database 
			Connection myCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Munstermad14");
			// 2. create a statement 
			Statement myStmt=myCon.createStatement();
			//3. execute sql query
			String sql = "delete from employees where name ='adam'";
			String sql2 = "delete from packages where type = 'small'";
			String sql3 ="delete from distribution where name = 'john'";
			String sql4 ="delete from orders where maker = 'apple'";
			
			
			int rowsaffected = myStmt.executeUpdate(sql);
			int rowsaffected2 = myStmt.executeUpdate(sql2);
			int rowsaffected3 = myStmt.executeUpdate(sql3);
			int rowsaffected4 = myStmt.executeUpdate(sql4);
			
			// 4. process result set 
			System.out.println("rows affected"+rowsaffected);
			System.out.println("rowsaffected"+rowsaffected2);
			System.out.println("rowsaffected"+rowsaffected3);
			System.out.println("rowsaffected"+rowsaffected4);
			System.out.println("delete complete");
		}
		catch (Exception exc) {
			exc.printStackTrace();
		}

	}

}
