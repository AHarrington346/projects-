import java.sql.*;
public class insert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			// 1. connection to database 
			Connection myCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Munstermad14");
			// 2. create a statement 
			Statement myStmt=myCon.createStatement();
			//3. execute sql query
			String sql = "insert into employees" +"(eID ,name,age,position)"+"values('11' , 'robinson' , '25' , 'Director')";
			String sql2 = "insert into packages" +"(pID ,pname,pweight,maker,type)"+"values('11' , 'samsung' , '5' , 'samsung','phone')";
			
			
			myStmt.executeUpdate(sql);
			myStmt.executeUpdate(sql2);
			
			// 4. process result set 
			System.out.println("insert complete");
		}
		catch (Exception exc) {
			exc.printStackTrace();
		}

	}

}
