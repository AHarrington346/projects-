import java.sql.*;
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// 1. connection to database 
			Connection myCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Munstermad14");
			// 2. create a statement 
			Statement myStmt=myCon.createStatement();
			//3. execute sql query
			ResultSet myres=myStmt.executeQuery("select * from employees");
			// 4. process reult set 
			while (myres.next()) {
				System.out.println(myres.getString("name")+","+myres.getString("position"));
			}
		}
		catch (Exception exc) {
			exc.printStackTrace();
		}
	}

}
